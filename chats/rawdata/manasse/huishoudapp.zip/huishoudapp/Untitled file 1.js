import React, { useMemo } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  ScrollView, 
  SafeAreaView,
  TouchableOpacity, 
  Dimensions, 
  StatusBar 
} from 'react-native';
import { AntDesign, Ionicons } from '@expo/vector-icons'; 

// Haal schermafmetingen op voor responsief ontwerp
const { width } = Dimensions.get('window');

// --- UX/UI ANALYSE ARTIFACT: KLEUREN & FONT ---
// Gebaseerd op de Lyra Prompt FASE 4.1 UX/UI Analyse
const COLORS = {
  primary: '#00A98F',        // Teal (Actie, Positief, Kalm)
  secondary: '#FF6B6B',      // Zacht Rood (Uitgaven, Kritieke Marge)
  background: '#F9F9F9',     // Zeer Lichtgrijs (Hoofdschermen)
  text: '#333333',           // Donkergrijs (Standaardtekst, Hoog Contrast)
  card: '#FFFFFF',           // Wit (Kaart achtergronden)
  neutral_accent: '#9CA3AF', // Zachte Grijstint
  success: '#90EE90',        // Lichtgroen (Inkomsten, Neutraal)
  shadow: 'rgba(0, 0, 0, 0.08)',
};

// Font is systeem default (schreefloos)


// --- MOCK DATA (Simulatie van Backend Data) ---

// 1. Risicomarge Simulatie
// Dit component simuleert de 'dagen marge' tot het budget kritiek wordt.
interface RiskMarginData {
  daysLeft: number;
  totalDaysInCycle: number;
  nextPayDay: string; // datum string
}

const MOCK_RISK_DATA: RiskMarginData = {
  daysLeft: 5, // Simuleer 5 dagen over (goede marge)
  totalDaysInCycle: 30, 
  nextPayDay: '30 november',
};

// Simuleer Kritieke Marge (voor testdoeleinden: zet daysLeft op 2)
const MOCK_CRITICAL_RISK_DATA: RiskMarginData = {
  daysLeft: 2, 
  totalDaysInCycle: 30, 
  nextPayDay: '30 november',
};


// 2. Recentste Transacties Mock
interface Transaction {
  id: string;
  amount: number;
  type: 'Uitgave' | 'Inkomst';
  category: string;
  date: string;
}

const MOCK_TRANSACTIONS: Transaction[] = [
  { id: 't1', amount: 45.50, type: 'Uitgave', category: 'Boodschappen', date: 'Vandaag' },
  { id: 't2', amount: 12.99, type: 'Uitgave', category: 'Bestellen - Eten', date: 'Vandaag' },
  { id: 't3', amount: 20.00, type: 'Uitgave', category: 'Kind - Zakgeld', date: 'Gisteren' },
  { id: 't4', amount: 2500.00, type: 'Inkomst', category: 'Salaris', date: '25-11' },
  { id: 't5', amount: 6.50, type: 'Uitgave', category: 'Vervoer - OV', date: '24-11' },
];


// --- COMPONENTEN EN SECTIES ---

/**
 * Visualiseert de Risicomarge als 'Beschikbare Dagen'
 * Gebaseerd op UX/UI Analyse, sectie 2.2
 */
const RiskMarginVisualizer: React.FC<{ data: RiskMarginData }> = ({ data }) => {
  
  const { daysLeft, totalDaysInCycle } = data;

  // Bepaal de kritieke drempel (onder 3 dagen is kritiek)
  const isCritical = daysLeft <= 3;

  // Bepaal de kleur van de balk en de tekst
  const barColor = isCritical ? COLORS.secondary : COLORS.primary;
  
  // Bereken het percentage voor de voortgangsbalk (relatief tot de hele cyclus)
  const percentage = (daysLeft / totalDaysInCycle) * 100;
  const barWidth = `${Math.max(0, Math.min(100, percentage))}%`; // Zorg ervoor dat het tussen 0% en 100% blijft
  
  const marginText = isCritical 
    ? `Actie vereist: Marge ${daysLeft} dag(en)`
    : `Nog ${daysLeft} dag(en) marge`;

  return (
    <View style={[styles.card, styles.riskCard]}>
      <Text style={styles.riskTitle}>Wat moet ik NU doen?</Text>
      
      <View style={styles.riskHeader}>
        <Text style={[styles.marginText, { color: isCritical ? COLORS.secondary : COLORS.text }]}>
          {marginText}
        </Text>
        <Text style={styles.payDayText}>
          Volgende inkomst: {data.nextPayDay}
        </Text>
      </View>

      {/* Voortgangsbalk */}
      <View style={styles.progressBarBackground}>
        <View style={[styles.progressBarFill, { width: barWidth, backgroundColor: barColor }]} />
      </View>

      <Text style={styles.riskTip}>
        De marge is het aantal dagen dat u nog kunt budgetteren met uw huidige uitgavenpatroon.
      </Text>

      {/* Actiepunt knop */}
      <TouchableOpacity 
        style={styles.quickAddButton}
        onPress={() => console.log('NAVIGATIE: Ga naar Quick Add Expense scherm')}
      >
        <Text style={styles.quickAddButtonText}>
          Snelle Uitgave Toevoegen
        </Text>
        <Ionicons name="add-circle-outline" size={24} color={COLORS.card} />
      </TouchableOpacity>
    </View>
  );
};


/**
 * Toont de lijst van recente transacties.
 * Gebaseerd op UX/UI Analyse, sectie 2.3
 */
const RecentTransactions: React.FC<{ transactions: Transaction[] }> = ({ transactions }) => {

  const totalToday = useMemo(() => {
    return transactions
      .filter(t => t.date === 'Vandaag' && t.type === 'Uitgave')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [transactions]);
  
  return (
    <View style={styles.recentSection}>
      <Text style={styles.sectionTitle}>Recentste Transacties</Text>

      <View style={styles.todaySummary}>
        <Text style={styles.todaySummaryText}>Totaal Uitgaven Vandaag:</Text>
        <Text style={styles.todaySummaryAmount}>
          €{totalToday.toFixed(2).replace('.', ',')}
        </Text>
      </View>

      <View style={styles.transactionList}>
        {transactions.map((t) => {
          const isExpense = t.type === 'Uitgave';
          const amountColor = isExpense ? COLORS.secondary : COLORS.success;
          const sign = isExpense ? '-' : '+';
          
          return (
            <View key={t.id} style={styles.transactionItem}>
              <View style={styles.transactionDetails}>
                <Text style={styles.transactionCategory}>{t.category}</Text>
                <Text style={styles.transactionDate}>{t.date}</Text>
              </View>
              <Text style={[styles.transactionAmount, { color: amountColor }]}>
                {sign}€{t.amount.toFixed(2).replace('.', ',')}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};


/**
 * Hoofd Dashboard Component
 */
const Dashboard: React.FC = () => {

  // We gebruiken de normale, niet-kritieke mock data voor de initiële weergave
  const riskData = MOCK_RISK_DATA; 

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        
        {/* HEADER */}
        <View style={styles.header}>
          <View>
            <Text style={styles.welcomeText}>Welkom terug, Lyra!</Text>
            <Text style={styles.currentDate}>Vandaag: 29 november 2025</Text>
          </View>
          <Ionicons name="person-circle-outline" size={40} color={COLORS.text} />
        </View>

        {/* 1. RISICOMARGE VISUALISATIE */}
        <RiskMarginVisualizer data={riskData} />
        
        {/* 2. RECENTSTE TRANSACTIES */}
        <RecentTransactions transactions={MOCK_TRANSACTIONS} />
        
        {/* EINDE ScrollView Padding */}
        <View style={{ height: 100 }} />

      </ScrollView>
      
      {/* 3. ACTIEKNOPPEN (Absolute Positionering) */}
      <View style={styles.actionButtonContainer}>
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => console.log('NAVIGATIE: Ga naar Detail Invoer Scherm')}
        >
          <AntDesign name="pluscircleo" size={24} color={COLORS.text} />
          <Text style={styles.actionButtonText}>+ Nieuwe Invoer (Detail)</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => console.log('NAVIGATIE: Ga naar Budgetten Overzicht')}
        >
          <Ionicons name="stats-chart-outline" size={24} color={COLORS.text} />
          <Text style={styles.actionButtonText}>📈 Bekijk Budgetten</Text>
        </TouchableOpacity>
      </View>
      
    </SafeAreaView>
  );
};

// --- STYLING (Aangepast aan UX/UI Analyse) ---

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollViewContent: {
    padding: 16,
    paddingBottom: 100, // Ruimte voor de absolute knoppen
  },

  // Header Stijlen
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },
  welcomeText: {
    fontSize: 22,
    fontWeight: '700',
    color: COLORS.text,
  },
  currentDate: {
    fontSize: 14,
    color: COLORS.neutral_accent,
  },

  // Algemene Kaart Stijl
  card: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },

  // 1. Risicomarge Stijlen
  riskCard: {
    borderLeftWidth: 5,
    borderLeftColor: COLORS.primary, // Zachte accentuering
  },
  riskTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 10,
  },
  riskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    marginBottom: 10,
  },
  marginText: {
    fontSize: 24,
    fontWeight: '800',
  },
  payDayText: {
    fontSize: 14,
    color: COLORS.neutral_accent,
    fontWeight: '500',
  },
  
  // Voortgangsbalk Stijlen
  progressBarBackground: {
    height: 12,
    backgroundColor: COLORS.neutral_accent + '33',
    borderRadius: 6,
    overflow: 'hidden',
    marginBottom: 10,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 6,
  },
  
  riskTip: {
    fontSize: 12,
    color: COLORS.neutral_accent,
    marginBottom: 15,
    fontStyle: 'italic',
  },
  
  quickAddButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    padding: 15,
    borderRadius: 12,
  },
  quickAddButtonText: {
    color: COLORS.card,
    fontSize: 16,
    fontWeight: '700',
    marginRight: 10,
  },

  // 2. Recentste Transacties Stijlen
  recentSection: {
    marginBottom: 20,
    paddingHorizontal: 0, // Kaartstijl niet van toepassing op de hele sectie
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 15,
    paddingHorizontal: 5,
  },
  todaySummary: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    backgroundColor: COLORS.card,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.secondary,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  todaySummaryText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
  todaySummaryAmount: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.secondary,
  },
  
  transactionList: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    paddingHorizontal: 15,
    paddingVertical: 10,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.background,
  },
  transactionDetails: {
    flex: 1,
  },
  transactionCategory: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.text,
  },
  transactionDate: {
    fontSize: 12,
    color: COLORS.neutral_accent,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: '700',
    paddingLeft: 10,
  },

  // 3. Actieknoppen (Onderaan scherm)
  actionButtonContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 16,
    paddingVertical: 15,
    backgroundColor: COLORS.card,
    borderTopWidth: 1,
    borderTopColor: COLORS.background,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -5 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 8,
    padding: 15,
    borderRadius: 12,
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.neutral_accent + '55',
  },
  actionButtonText: {
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
  },
});

export default Dashboard;