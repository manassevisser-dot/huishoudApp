// App.js

import * as React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// ---------------------------------------------------------------- //
// 1. Scherm Definities
// ---------------------------------------------------------------- //

function LoginScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>1. Inloggen / Registreren</Text>
      <Button
        title="Ga naar Dashboard"
        // Dit simuleert een succesvolle login
        onPress={() => navigation.navigate('Dashboard')}
      />
    </View>
  );
}

function DashboardScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>2. Dashboard (Overzicht)</Text>
      <View style={styles.buttonGroup}>
        <Button
          title="Nieuwe Invoer"
          onPress={() => navigation.navigate('NieuweInvoer')}
        />
        <Button
          title="Uitloggen"
          // In een echte app zou dit naar het Login scherm navigeren
          onPress={() => navigation.navigate('Login')}
        />
      </View>
    </View>
  );
}

function NieuweInvoerScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>3. Nieuwe Invoer Scherm</Text>
      <Button
        title="Terug naar Dashboard"
        onPress={() => navigation.goBack()}
      />
    </View>
  );
}

// ---------------------------------------------------------------- //
// 2. Navigatie Stack
// ---------------------------------------------------------------- //

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Dashboard" component={DashboardScreen} />
        <Stack.Screen name="NieuweInvoer" component={NieuweInvoerScreen} options={{ title: 'Uitgave Registreren' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// ---------------------------------------------------------------- //
// 3. Basis Styling
// ---------------------------------------------------------------- //

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff', 
  },
  text: {
    fontSize: 18,
    marginBottom: 20,
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '60%',
  }
});
