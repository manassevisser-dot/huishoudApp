import React, { useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';

// Importeer het Setup Scherm vanuit de 'screens' map
import SetupScreen from './screens/SetupScreen';

// --- MOCK DASHBOARD (Ter Vervanging in de echte app) ---
const DashboardScreen = ({ onReset }) => (
  <View style={dashboardStyles.container}>
    <Text style={dashboardStyles.title}>Dashboard (Mock)</Text>
    <Text style={dashboardStyles.subtitle}>
      Dit is waar de app na succesvolle setup naartoe navigeert.
    </Text>
    <TouchableOpacity 
        style={dashboardStyles.resetButton} 
        onPress={onReset}
    >
      <Text style={dashboardStyles.resetButtonText}>Herstart Setup (Test)</Text>
    </TouchableOpacity>
  </View>
);

const dashboardStyles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00A98F',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    color: '#333',
    marginBottom: 30,
  },
  resetButton: {
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#FF6B6B',
  },
  resetButtonText: {
    color: 'white',
    fontWeight: 'bold',
  }
});


// --- HOOFD COMPONENT MET NAVIGATIE LOGICA ---

const App: React.FC = () => {
  // 'setup' toont het Setup scherm, 'dashboard' toont het Dashboard (Mock)
  const [currentScreen, setCurrentScreen] = useState<'setup' | 'dashboard'>('setup');

  const handleSetupComplete = () => {
    // Navigatie logica na succesvol opslaan in SetupScreen
    setCurrentScreen('dashboard');
  };
  
  const handleReset = () => {
      // Om de setup opnieuw te testen
      setCurrentScreen('setup');
  }

  // Hier renderen we het gekozen scherm
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#F9F9F9' }}>
      {currentScreen === 'setup' ? (
        // We injecteren de navigatie functie als prop in het SetupScreen
        <SetupScreen onSetupComplete={handleSetupComplete} />
      ) : (
        <DashboardScreen onReset={handleReset} />
      )}
    </SafeAreaView>
  );
};

export default App;