import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { useForm } from '../../../app/context/FormContext';
import { useAppStyles } from '../../styles/useAppStyles';
import FormField from '../../components/fields/FormField';
import { Logger } from '../../../services/logger'; // Centraal loggen
import { Strings } from '../../../utils/strings';   // Geen inline teksten

export const WizardPage: React.FC<any> = ({ config, onNext, onBack, isFirst, isLast }) => {
  const { state, dispatch } = useForm();
  const { styles } = useAppStyles();

  React.useEffect(() => {
    // WAI-009: Log schermwisseling centraal
    Logger.info(`Wizard stap geladen: ${config.title}`);
  }, [config.title]);

  return (
    <View style={styles.container}>
      <Text 
        style={styles.pageTitle}
        accessibilityRole="header"
        accessibilityLiveRegion="assertive"
      >
        {config.title} 
      </Text>
      
      <ScrollView style={{ flex: 1 }}>
        {config.fields.map((field) => (
          <FormField
            key={field.id}
            field={field}
            state={state}
            dispatch={dispatch}
            value={state[field.id] ?? state.setup?.[field.id]} 
          />
        ))}
      </ScrollView>

      <View style={styles.buttonContainer}>
        {!isFirst && (
          <TouchableOpacity onPress={onBack}>
            <Text>{Strings.wizard.back}</Text> 
          </TouchableOpacity>
        )}
        <TouchableOpacity onPress={onNext} style={styles.button}>
          <Text style={styles.buttonText}>
            {isLast ? Strings.wizard.finish : Strings.wizard.next}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};