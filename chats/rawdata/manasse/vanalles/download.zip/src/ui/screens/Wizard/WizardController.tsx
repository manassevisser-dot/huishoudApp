import * as React from 'react';
import { useState, useMemo, useCallback } from 'react';
import { useForm } from '@app/context/FormContext';
import WizardPage from './WizardPage';

// Directe imports van de pagina-configs
import { setupHouseholdConfig } from './pages/1setupHousehold.config';
import { detailsHouseholdConfig } from './pages/2detailsHousehold.config';
import { incomeDetailsConfig } from './pages/3incomeDetails.config';
import { fixedExpensesConfig } from './pages/4fixedExpenses.config';

export const WizardController: React.FC = () => {
  // We halen de state alleen op voor de SYNC_MEMBERS logica
  const { state, dispatch } = useForm();
  const [currentPageIndex, setCurrentPageIndex] = useState(0);

  const wizardSteps = useMemo(() => [
    setupHouseholdConfig,
    detailsHouseholdConfig,
    incomeDetailsConfig,
    fixedExpensesConfig,
  ], []);

  const currentPageConfig = wizardSteps[currentPageIndex];

  const handleNext = useCallback(() => {
    // Business Rule: Synchronisatie bij stap 1
    if (currentPageConfig?.id === '1setupHousehold') {
      const aantal = state.setup?.aantalMensen ?? 1;
      dispatch({
        type: 'SYNC_MEMBERS',
        payload: { count: aantal },
      });
    }

    if (currentPageIndex < wizardSteps.length - 1) {
      setCurrentPageIndex((prev) => prev + 1);
    }
  }, [currentPageConfig?.id, currentPageIndex, wizardSteps.length, state.setup?.aantalMensen, dispatch]);

  const handleBack = useCallback(() => {
    if (currentPageIndex > 0) {
      setCurrentPageIndex((prev) => prev - 1);
    }
  }, [currentPageIndex]);

  if (!currentPageConfig) return null;

  return (
    <WizardPage
      config={currentPageConfig}
      onNext={handleNext}
      onBack={handleBack}
      isFirst={currentPageIndex === 0}
      isLast={currentPageIndex === wizardSteps.length - 1}
    />
  );
};

export default WizardController;