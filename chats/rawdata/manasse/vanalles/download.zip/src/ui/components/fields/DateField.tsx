import * as React from 'react';
import { Platform, View, Text, Pressable } from 'react-native';
import DateTimePicker, { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { useAppStyles } from '@ui/styles/useAppStyles';
import { formatDate } from '@utils/date';

type Props = {
  label: string;
  valueISO?: string; // canoniek: 'YYYY-MM-DD'
  onChangeISO: (iso: string | undefined) => void;
  minISO?: string; // default: '1920-01-01'
  maxISO?: string; // default: vandaag
  errorText?: string | null;
  accessibilityLabel?: string;
};

const isoToDate = (iso?: string): Date => {
  if (!iso) return new Date();
  const [y, m, d] = iso.split('-').map(Number);
  // UTC noon voorkomt dagverschuiving door tijdzones
  return new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1, 12, 0, 0));
};

const isoToday = (): string => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const dateToISO = (dt: Date): string => {
  // Niet toISOString(); dat geeft TZ issues. Formatteer zelf naar YYYY-MM-DD (UTC)
  const y = dt.getUTCFullYear();
  const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
  const d = String(dt.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const DateField: React.FC<Props> = ({
  label,
  valueISO,
  onChangeISO,
  minISO = '1920-01-01',
  maxISO,
  errorText,
  accessibilityLabel,
}) => {
  const { styles, colors } = useAppStyles() as any;
  const [show, setShow] = React.useState(false);

  const max = maxISO ?? isoToday();
  const display = valueISO ? formatDate(valueISO, 'dd-mm-yyyy') : '';

  return (
    <View style={styles.fieldContainer}>
      <Text style={styles.fieldLabel}>{label}</Text>

      <Pressable
        onPress={() => setShow(true)}
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel ?? label}
        style={[styles.input, { justifyContent: 'center' }, errorText && styles.inputError]}
      >
        <Text style={{ color: display ? colors.textPrimary : colors.textSecondary }}>
          {display || 'DD-MM-YYYY'}
        </Text>
      </Pressable>

      {show && (
        <DateTimePicker
          mode="date"
          value={valueISO ? isoToDate(valueISO) : isoToDate(max)}
          minimumDate={isoToDate(minISO)}
          maximumDate={isoToDate(max)}
          display={Platform.OS === 'ios' ? 'spinner' : 'calendar'}
          onChange={(event: DateTimePickerEvent, date?: Date) => {
            if (Platform.OS === 'android') setShow(false);
            if (event.type === 'dismissed') return;
            if (!date) return;
            const iso = dateToISO(date);
            onChangeISO(iso);
          }}
        />
      )}

      {errorText && <Text style={styles.errorTextStyle}>{errorText}</Text>}
    </View>
  );
};

export default DateField;
