const Logger = {
  info: (msg: string, data?: any) => console.log(msg, data),
  error: (msg: string, err?: any) => console.error(msg, err),
  warn: (msg: string, data?: any) => console.warn(msg, data), // Voeg deze regel toe
  log: (level: string, msg: string, ...args: any[]) => console.log(`[${level}]`, msg, ...args),
};

export default Logger;
export const logger = Logger;